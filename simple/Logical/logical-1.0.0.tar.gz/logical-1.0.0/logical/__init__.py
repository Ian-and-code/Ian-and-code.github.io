"""
lenguje implemtado paea que puedas usar pueratas logicas mas facil mente
"""
__version__ = "1.0.0"
import ply.lex as lex
import ply.yacc as yacc

# ---------------- LEXER ----------------
tokens = [
    "AND", "OR", "XOR", "NOT", "CEQ",
    "ID", "NUMBER", "LP", "RP", "EQ", "SCOLON"
]
t_SCOLON = r";"
t_CEQ = r"=="
t_EQ = r"="
t_LP = r"\("
t_RP = r"\)"

# Operadores lógicos
def t_AND(t):
    r"and|&"
    t.value = "and"
    return t

def t_OR(t):
    r"or|\|"
    t.value = "or"
    return t

def t_XOR(t):
    r"\^|!\|"
    t.value = "^"
    return t

def t_NOT(t):
    r"not|!"
    t.value = "not"
    return t

t_ignore = " \t"

# Números decimales
def t_NUMBER(t):
    r"-?\d+(\.\d+)?"
    if '.' in t.value:
        t.value = float(t.value)
    else:
        t.value = int(t.value)
    return t

# Identificadores
def t_ID(t):
    r"[A-Za-z_][A-Za-z0-9_]*"
    return t

def t_newline(t):
    r"\n+"
    t.lexer.lineno += len(t.value)

def t_comment(t):
    r"\#.*"
    pass

def t_error(t):
    print(f"Illegal character {t.value[0]!r} at line {t.lexer.lineno}")
    t.lexer.skip(1)

lexer = lex.lex()

# ---------------- PARSER ----------------
precedence = (
    ("right", "NOT"),
    ("left", "AND", "OR"),
    ("left", "XOR")
)

env = {}

# Contenedor de múltiples statements
def p_statements_multi(p):
    "statements : statements stmt"
    p[0] = p[1] + [p[2]]

def p_statements_single(p):
    "statements : stmt"
    p[0] = [p[1]]

# Asignación
def p_stmt_assign(p):
    "stmt : ID EQ expr SCOLON"
    env[p[1]] = p[3]
    p[0] = p[3]

# Operadores binarios
def p_expr_binop(p):
    """expr : expr AND expr
            | expr OR expr
            | expr XOR expr
            | expr CEQ expr"""
    if p[2] == "and":
        p[0] = int(p[1] and p[3])
    elif p[2] == "or":
        p[0] = int(p[1] or p[3])
    elif p[2] == "^":
        p[0] = int((p[1] and (not p[3])) or ((not p[1]) and p[3]))#A XOR B es igual a (A AND (NO B)) OR ((NO A) AND B)
    elif p[2] == "==":
        p[0] = int(p[1] == p[3])

# Operador NOT
def p_expr_not(p):
    "expr : NOT expr"
    p[0] = int(not p[2])

# Paréntesis
def p_expr_group(p):
    "expr : LP expr RP"
    p[0] = p[2]

# Números
def p_expr_number(p):
    "expr : NUMBER"
    p[0] = p[1]

# Identificadores
def p_expr_id(p):
    "expr : ID"
    p[0] = env.get(p[1], 0)

def p_error(p):
    print("Syntax error!")

parser = yacc.yacc()
def get(var: str):
    return env.get(var, None)

def set(var: str, val) -> None:
    env[var] = val
    return None
# ---------------- EJEMPLO ----------------
code = """
a = 1;
b = 0;
c = a == b;
d = !a;
e = (a & b) | c;
z = 3.14;
"""

logic = lambda code: parser.parse(code, lexer=lexer)
